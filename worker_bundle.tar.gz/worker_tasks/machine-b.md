# Machine B: HGPO Reproduction and Independent Audit

## Objective

Reproduce a small official HGPO ALFWorld run, preserve every raw trajectory, and
independently evaluate whether hierarchical state grouping retains enough
context for MEMOIR audit.

## Required work

1. Read the HGPO recipe README, paper-linked configuration, and official launch
   scripts. Use official settings where they fit two A100 80GB GPUs and record
   every deviation.
2. Inspect the HGPO entrypoint, rollout collector, and `core_hgpo.py`
   hierarchical grouping logic at the pinned revision.
3. Determine whether stock logging persists complete raw trajectories. Record
   its config key, writer, format, and reader, then inspect a one-prompt artifact
   before modifying code.
4. Add the audit logging contract only for missing fields, without changing HGPO advantage computation
   when audit logging is disabled.
5. Record both exact `anchor_obs` used for grouping and full policy-visible
   context. Never infer that identical `anchor_obs` means identical context.
6. Add a test with identical `anchor_obs` but different histories and verify
   that the audit export preserves the distinction.
7. Reproduce the smallest official HGPO comparison that fits the hardware, then
   collect at least five ALFWorld prompt groups with eight trajectories each,
   using seeds distinct from Machine A's documented default lane.
8. Report success/reward metrics, official-command deviations, hierarchy-level
   group counts, outcome-contrast groups, validator status, raw trajectory
   location/format, incomplete trajectories, and artifact hashes.

## Stop conditions

Do not claim algorithm superiority from a reduced-budget run. Do not report
hierarchy membership as proof of information equivalence or causal criticality.
