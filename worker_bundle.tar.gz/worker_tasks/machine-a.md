# Machine A: GraphGPO and GiGPO Reproduction

## Objective

Reproduce small official GraphGPO and GiGPO ALFWorld runs, preserve every raw
trajectory, and make both methods exportable under one audit contract.

## Required work

1. Read the GraphGPO and GiGPO recipe READMEs and official launch scripts. Use
   their official environment, model, and hyperparameters whenever they fit two
   A100 80GB GPUs; record every necessary deviation.
2. Inspect `recipe/GraphGPO/rollout_loop.py` and all called prompt-rendering,
   action-parsing, environment-step, and batch-serialization code.
3. Determine whether the stock repository already persists complete raw
   trajectories. Document the exact config key, writer, format, and reader. Run
   a one-prompt smoke test and inspect the saved artifact before changing code.
4. If any required field is absent, add the audit logging contract from
   `WORKER_INSTRUCTIONS.md` behind an
   `audit.enabled`-style configuration flag.
5. Preserve stock GraphGPO/GiGPO fields and behavior when the flag is disabled.
6. Save one prompt group for each method, run the MEMOIR exporter and validator, and fix
   all errors. Treat missing exact context and executed action warnings as
   release blockers for this lane.
7. Reproduce the smallest official comparison that fits the hardware budget,
   then expand audit collection to at least five prompt groups with eight
   trajectories per prompt per method.
8. Report method-level success/reward metrics, official-command deviations,
   outcome-contrast group count, incomplete trajectories, validator status,
   raw trajectory location/format, and artifact hashes.

## Stop conditions

Do not implement MEMOIR reward or credit routing. Do not infer critical atoms
automatically. Reproducing an official post-training run is allowed only after
the rollout smoke test proves that every trajectory is durably logged.
