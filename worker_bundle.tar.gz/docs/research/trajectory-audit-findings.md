# Trajectory Audit: Source Findings and Decisions

Last updated: 2026-08-19

## Scope

This note records the first-pass audit of GraphGPO, GiGPO, and HGPO in
`langfengQ/verl-agent`. It distinguishes repository evidence from proposed
MEMOIR instrumentation. No statement below is a causal experimental result.

## Repository evidence

The repository is suitable as the base because grouped rollout identity is
already explicit:

- GraphGPO rollout collection assigns one `uid` to all rollouts sampled from the
  same prompt and a distinct `traj_uid` to each trajectory.
- Example training configuration uses `env.rollout.n=8`, producing eight
  same-prompt trajectories.
- Step data include `anchor_obs`, `next_obs`, `text_actions`, rewards, active
  masks, episode reward, and token tensors.
- GraphGPO builds a state-transition graph over all rollouts. Edges retain the
  action, prompt identity, trajectory identity, and outcome.
- GiGPO groups repeated `anchor_obs` values within a prompt group to compute
  step-level relative advantages. It may use string similarity as a relaxed
  state match.
- HGPO uses observation and history structure to construct hierarchical,
  context-aware state groups.

The public GraphGPO tree includes visualization directories for three tasks,
with eight trajectories per task. These are trajectory graph PDFs, not the raw
serialized rollout batches. The public repository does not expose enough exact
policy-visible text, raw producer spans, or memory state to conduct a defensible
information-atom audit from those PDFs alone.

## Important representation distinction

`anchor_obs` is useful for environment-state grouping, but it is not necessarily
the full context visible to the policy. An audit must preserve both:

1. the raw environment observation/state used for grouping; and
2. the exact rendered model context at the decision checkpoint.

This distinction is required to separate information that was absent from
information that was present but not used.

## Audit definitions

For semantic checkpoint `k`, candidate required information is represented as a
set of roles `R_k`; all roles accessible to the policy are `A_k`. A candidate is
eligible for audit only when supported by at least one of:

- a tool/API precondition;
- a verifier dependency;
- a producer-to-consumer provenance path; or
- a role contrast between aligned same-prompt rollouts.

Without grounded support, the correct label is `abstain`. If required information
is available but the action is wrong, the failure belongs to utilization or
execution rather than information insufficiency.

An information atom is `(role, entity, value, lifecycle status, source step,
immutable raw provenance, extraction confidence)`. The representation is an
evidence lattice: raw span or schema field, extractive clause, normalized
role-value proposition, and possibly a bundle. Alternative split/merge analyses,
coreference, temporal scope, and conflicts must remain visible.

## First data-collection decision

Use ALFWorld for the first audit batch because it is textual, multi-step, and
contains interpretable observations and actions. Sample at least eight rollouts
per prompt and prioritize prompt groups containing both success and failure.

The upstream collector should add these fields before writing the batch:

- exact `model_context_text` before chat templating;
- exact `rendered_prompt_text` after chat templating, where recoverable;
- raw `anchor_obs` and `next_obs`;
- decoded model action and actual executed/projected action;
- memory snapshot and provenance identifiers;
- semantic environment/task identifier, seed, step index, model revision, and
  decoding configuration.

Raw character and byte offsets must be retained. A summary may index raw
evidence but must never replace it.

## Phase-one gate

Before training or causal claims, report candidate coverage, abstention rate,
annotator agreement, failure/lifecycle distributions, split/merge stability,
semantic alignment agreement, ownership separability, and replayable fraction.
Low grounded coverage or agreement should trigger a representation revision.

Observation alone cannot establish information necessity/sufficiency, MEMOIR
training gains, rerollout-critic calibration, or superiority to causal replay
baselines. Those require matched removal/injection/timing rerollouts and training
ablations.
