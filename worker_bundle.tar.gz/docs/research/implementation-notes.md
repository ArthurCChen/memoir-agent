# Implementation Notes

## 2026-08-19: Initial audit framework

### Decisions

- Selected `langfengQ/verl-agent` as the upstream base and pinned revision
  `20bd331bdbc9026a5668e11362178e10ab7400c8` for the first collection pass.
- Kept the audit tooling as a small, dependency-light overlay because the local
  workstation does not currently contain a complete upstream checkout and
  cannot reach GitHub from the shell.
- Used `uid` as prompt-group identity and `traj_uid` as trajectory identity.
- Preserved `anchor_obs` separately from exact policy-visible context.
- Prioritized success/failure outcome-contrast groups in the annotation queue.
- Represented annotations at `(rollout, semantic checkpoint, candidate)`
  granularity, while preserving bundle and split/merge alternatives.
- Required grounded support for critical-context candidates and made abstention
  an explicit label.

### Implemented

- A lazy-loading `.pth`/JSON exporter for DataProto-like column stores.
- Stable rollout and prompt-group JSONL artifacts.
- A contrast-first checkpoint annotation queue builder.
- A readiness validator that fails closed when audit-critical fields are absent.
- JSON Schemas for rollout and annotation records.
- Synthetic unit tests for grouping, ordering, outcome contrast, and queue
  construction.
- A standalone reproduction guide for strong-GPU machines.

### Verification

```text
python3 -m unittest discover -s experiments/trajectory_audit/tests -v
Ran 3 tests: OK
```

Both executable modules also passed `python3 -m py_compile`.

### Known gaps

- No raw public GraphGPO rollout batch has been found; included visualizations
  are insufficient for exact evidence-span annotation.
- The exporter has not yet been tested against a real upstream `.pth` artifact.
- Exact upstream hook locations must be confirmed in a pinned full checkout.
- Terminal success currently defaults to positive episode reward. Environment-
  specific verifier output should replace this heuristic when collected.
- Token counts, tool-call counts, costs, and full decoding configuration still
  need to be attached at run level.

### Next experiment gate

Collect a small ALFWorld pilot with at least eight rollouts per prompt, export it,
and manually inspect five outcome-contrast prompt groups. Do not launch a full
training experiment until exact context/provenance coverage and checkpoint
replay metadata pass validation.

## 2026-08-19: Download-only GPU control plane

- Created the private target repository `ArthurCChen/memoir-agent`.
- Added root `AGENTS.md` and `CLAUDE.md` entrypoints for unattended Claude Code
  execution on two download-only GPU workers.
- Assigned Machine A to GraphGPO plus GiGPO and Machine B to HGPO plus an
  independent audit-readiness check.
- Confirmed that all three official ALFWorld 1.5B scripts target two GPUs and
  use eight same-prompt rollouts.
- Confirmed that `trainer.rollout_data_dir` writes decoded input/output/score
  JSONL, but does not persist the in-memory per-step `uid`, `traj_uid`,
  observations, actions, and masks required for MEMOIR audit.
- Specified a minimal extension to the existing trainer logging block: retain
  stock JSONL, add a lossless full-batch `.pth`, and emit ordered human-readable
  trajectory JSONL under a separate explicit config option.
- Added a single-screen SVG renderer for modified files, tests, method-level
  reproduction results, pilot coverage, hashes, blockers, and next action.
