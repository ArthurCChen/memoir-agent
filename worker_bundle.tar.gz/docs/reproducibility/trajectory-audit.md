# Reproducing the MEMOIR Trajectory Audit

This guide is written for teammates running `verl-agent` on strong-GPU machines.
Record every deviation from the pinned revisions and commands below.

## 1. Pin the source

```bash
git clone https://github.com/langfengQ/verl-agent.git
cd verl-agent
git checkout 20bd331bdbc9026a5668e11362178e10ab7400c8
git submodule update --init --recursive
```

Copy the `experiments/trajectory_audit` directory from the MEMOIR repository into
the checkout, or add the MEMOIR repository to `PYTHONPATH`. Do not silently run
against a moving `master` branch.

## 2. Capture the machine manifest

Save the following before starting a run:

```bash
git rev-parse HEAD
git status --short
python --version
pip freeze
nvidia-smi
```

Also record CUDA, driver, GPU model/count, hostname, scheduler job identifier,
container image digest, dataset/environment revision, model identifier and
revision, random seeds, and all Hydra overrides. Store this in
`artifacts/<run-id>/manifest.txt` or an equivalent immutable experiment record.

## 3. Instrument policy-visible context

The stock GraphGPO fields are necessary but insufficient for information audit.
At every environment step, write these non-tensor columns alongside `uid` and
`traj_uid`:

- `model_context_text`: exact human-readable content visible to the policy;
- `rendered_prompt_text`: exact chat-template rendering, if available;
- `executed_action`: post-parser/projector action delivered to the environment;
- `memory_snapshot`: structured memory records with immutable provenance;
- `task_instance_id`, `environment_seed`, and `step_index`.

Never retain only a generated summary. Preserve the source observation/tool
result and stable character and byte offsets. Redact secrets before collection,
not during downstream annotation, so offsets remain stable within the archived
artifact.

## 4. Collect same-prompt rollouts

Start with ALFWorld and set the rollout group size to at least eight:

```bash
env.rollout.n=8
```

Use the repository's current ALFWorld GraphGPO/GiGPO training or evaluation
entrypoint and retain the complete command. For the initial audit, a rollout-only
or evaluation job is sufficient; avoid spending a full training budget before
verifying the exported evidence.

Save the serialized rollout `DataProto` batch as `.pth`. Confirm that each prompt
has one shared `uid`, each rollout has a distinct `traj_uid`, and the added
policy-context fields have one value per step.

## 5. Export stable audit artifacts

From the MEMOIR repository root:

```bash
python -m experiments.trajectory_audit.export_rollouts \
  /path/to/batch.pth artifacts/<run-id> \
  --source-revision 20bd331bdbc9026a5668e11362178e10ab7400c8

python -m experiments.trajectory_audit.validate_export \
  artifacts/<run-id>/rollouts.jsonl

python -m experiments.trajectory_audit.build_annotation_queue \
  artifacts/<run-id>/rollouts.jsonl \
  artifacts/<run-id>/annotation_queue.jsonl
```

The default queue includes only same-prompt groups with outcome contrast. Use
`--include-no-contrast` only for a separately reported audit stratum.

## 6. Validate before annotation

Check all of the following:

- every trajectory has a non-empty task, context, observation, and action;
- step order is correct and terminal reward/outcome is consistent;
- at least two trajectories share each queued prompt-group identifier;
- success/failure groups truly represent the same underlying task instance;
- the model context can be traced back to raw observations without lossy
  summarization;
- environment state and random seed are sufficient for checkpoint replay.

Hash all produced files, then make the raw batch and manifest read-only in the
experiment store. An example command is `sha256sum artifacts/<run-id>/*` on
Linux or `shasum -a 256 artifacts/<run-id>/*` on macOS.

## 7. Human annotation protocol

Use two independent annotators for the gated pilot. Align trajectories by
semantic subtask rather than absolute step. A critical-context candidate must
cite exact producer and consumer spans and one allowed support source. Otherwise
label it `abstain`.

Report coverage and agreement before resolving disagreements. Adjudication must
preserve both original labels and a disagreement reason. Do not describe an
observational criticality label as a causal effect.

## 8. Minimum handoff bundle

Share:

- pinned source and MEMOIR revisions;
- complete launch command and environment manifest;
- raw `.pth` batch and hashes;
- `rollouts.jsonl`, `groups.jsonl`, and `annotation_queue.jsonl`;
- annotation schema version;
- stdout/stderr and any failed-run notes;
- a short deviations file, even when it says `none`.
