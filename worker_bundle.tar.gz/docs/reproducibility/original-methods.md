# Reproducing GraphGPO, GiGPO, and HGPO on Two A100 GPUs

This matrix is based on the official launch scripts at upstream revision
`20bd331bdbc9026a5668e11362178e10ab7400c8`. It is a worker execution plan, not
an experimental result.

## Shared official setting

All three ALFWorld 1.5B recipes already target one node with two GPUs and use:

- `Qwen/Qwen2.5-1.5B-Instruct`;
- `env.env_name=alfworld/AlfredTWEnv`;
- `train_data_size=16` and `val_data_size=128`;
- `env.rollout.n=8` same-prompt trajectories;
- `env.max_steps=50`;
- tensor parallel size 2;
- sampled validation at temperature 0.4.

Use these scripts as the immutable starting point:

| Method | Official entrypoint | Official epochs | Key method setting |
|---|---|---:|---|
| GraphGPO | `recipe/GraphGPO/run_qwen2.5_1.5b_alfworld_train.sh` | 150 | `gamma=0.10`, graph step/episode weights 1.0 |
| GiGPO | `examples/gigpo_trainer/run_alfworld.sh` | 150 | `gamma=0.95`, step weight 1.0 |
| HGPO | `recipe/hgpo/run_qwen2.5_1.5b_alfworld_train.sh` | 160 | history 2, length weight, alpha 1.0 |

Machine A runs GraphGPO and GiGPO. Machine B runs HGPO. First run one global
step or the smallest supported smoke configuration; only proceed to the
reduced-budget reproduction after trajectory persistence passes inspection.

## Stock trajectory logging: confirmed boundary

The three trainers inherit or duplicate a `trainer.rollout_data_dir` hook. When
enabled, `_dump_generations` writes `<global_step>.jsonl` with decoded `input`,
decoded `output`, scalar `score`, global `step`, and length-matched reward extra
fields.

Enable this stock path during the smoke test:

```bash
+trainer.rollout_data_dir=/local/path/stock-rollouts
```

This is useful but not sufficient for MEMOIR. The in-memory rollout batch
contains `uid`, `traj_uid`, `anchor_obs`, `next_obs`, `text_actions`, rewards,
and active masks. The stock JSONL writer does not serialize those fields and
does not preserve exact per-decision context or executed action. The GraphGPO
visualizers accept a manually saved DataProto-like `.pth`, but the official
launch script does not expose a complete raw-batch persistence option.

Therefore, workers must retain both:

1. the untouched stock JSONL for reproduction comparability; and
2. an audit extension that saves the full batch plus human-readable ordered
   trajectory JSONL.

Do not overwrite or reinterpret the stock JSONL.

## Minimal implementation target

Extend the existing `rollout_data_dir` block in each applicable trainer rather
than creating an unrelated logging subsystem:

- `recipe/GraphGPO/graphgpo_ray_trainer.py`;
- `verl/trainer/ppo/ray_trainer.py` for GiGPO;
- `recipe/hgpo/hgpo_ray_trainer.py`.

Under a new explicit `trainer.audit_rollout_data_dir` option:

1. atomically save the complete CPU batch for each global step as `.pth`;
2. export rows grouped by `uid` and ordered within `traj_uid`;
3. retain exact context, raw observation, decoded action, executed action,
   reward, active mask, termination, task identity, and seed;
4. write a manifest with method, revision, config, model, and file hashes;
5. leave all existing outputs and training behavior unchanged when the new
   option is absent.

The `.pth` batch is for lossless inspection and the JSONL is for human reading.
Neither artifact is a restorable environment checkpoint unless environment,
RNG, model-sampling, parser, and memory state are captured separately.

## Reproduction stages

### Stage R0: environment and stock smoke test

- Run the unmodified official command with a one-step/small-data override.
- Enable `trainer.rollout_data_dir`.
- Confirm eight same-prompt samples appear and document the stock JSONL fields.

### Stage R1: audit persistence smoke test

- Apply the minimal logger extension.
- Run one prompt group with eight trajectories.
- Run MEMOIR export and validation.
- Manually open all eight trajectories side by side.

### Stage R2: reduced-budget reproduction

- Run all three methods with the same model, train/validation sizes, and an
  explicitly equalized number of optimizer steps or environment interactions.
- Keep official method-specific hyperparameters.
- Report both the official-budget target and the reduced budget actually used.

### Stage R3: official-budget continuation

- Continue only after R0-R2 artifacts pass validation and storage capacity is
  estimated.
- Preserve every raw rollout batch; storage pressure is not permission to
  discard unsuccessful or interrupted trajectories.

## Comparison outputs

For each method and seed, record success rate, mean episode reward, episode
length, invalid-action rate, tool calls, environment interactions, optimizer
steps, wall time, peak GPU memory, trajectory bytes, and complete/incomplete
trajectory counts. Comparisons must state budget and configuration deviations.
