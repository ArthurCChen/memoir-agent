#!/usr/bin/env python3
"""Render one sanitized, photograph-ready SVG from a worker result JSON."""

from __future__ import annotations

import argparse
import html
import json
import textwrap
from pathlib import Path
from typing import Any


WIDTH = 1600
HEIGHT = 1000


def esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


def wrapped(value: Any, width: int) -> list[str]:
    return textwrap.wrap(str(value), width=width, break_long_words=False, break_on_hyphens=False) or [""]


def text_lines(parts: list[str], x: int, y: int, lines: list[str], css_class: str = "body", gap: int = 27) -> int:
    for line in lines:
        parts.append(f'<text x="{x}" y="{y}" class="{css_class}">{esc(line)}</text>')
        y += gap
    return y


def render(result: dict[str, Any]) -> str:
    status = result["status"]
    status_color = {"PASS": "#33d17a", "PARTIAL": "#f6d32d", "BLOCKED": "#ff6b6b"}[status]
    revisions = result["revisions"]
    tests = result["tests"]
    pilot = result["pilot"]
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}">',
        "<style>",
        ".title{font:700 38px ui-monospace,monospace;fill:#f8fafc}.h{font:700 23px ui-monospace,monospace;fill:#7dd3fc}",
        ".body{font:19px ui-monospace,monospace;fill:#e2e8f0}.small{font:16px ui-monospace,monospace;fill:#94a3b8}",
        ".metric{font:700 26px ui-monospace,monospace;fill:#f8fafc}.path{font:17px ui-monospace,monospace;fill:#c4b5fd}",
        "</style>",
        '<rect width="1600" height="1000" fill="#07111f"/>',
        '<rect x="28" y="28" width="1544" height="944" rx="18" fill="#0f1b2d" stroke="#334155" stroke-width="2"/>',
        f'<circle cx="1510" cy="71" r="20" fill="{status_color}"/>',
        f'<text x="1470" y="79" text-anchor="end" class="metric">{esc(status)}</text>',
        f'<text x="62" y="80" class="title">MEMOIR · {esc(result["machine"])} · {esc(result["lane"])}</text>',
        f'<text x="64" y="119" class="small">MEMOIR {esc(revisions["memoir"])}  ·  verl-agent {esc(revisions["upstream"])}</text>',
        '<line x1="62" y1="143" x2="1538" y2="143" stroke="#334155"/>',
    ]

    parts.extend([
        '<text x="64" y="188" class="h">VERIFICATION</text>',
        f'<text x="64" y="230" class="metric">{tests["passed"]} tests passed · {tests["failed"]} failed</text>',
        f'<text x="64" y="262" class="small">{esc(str(tests["summary"])[:72])}</text>',
        '<text x="850" y="188" class="h">PILOT</text>',
        f'<text x="850" y="230" class="metric">{pilot["prompt_groups"]} prompts · {pilot["rollouts"]} rollouts · {pilot["contrast_groups"]} contrast</text>',
        f'<text x="850" y="262" class="small">export validator: {esc(pilot["validator"])}</text>',
        '<line x1="62" y1="291" x2="1538" y2="291" stroke="#334155"/>',
        '<text x="64" y="330" class="h">METHOD REPRODUCTIONS</text>',
    ])

    run_y = 366
    if not result["runs"]:
        parts.append(f'<text x="64" y="{run_y}" class="body">No method runs recorded.</text>')
    for run in result["runs"][:3]:
        rate = "—" if run["success_rate"] is None else f'{100 * run["success_rate"]:.1f}%'
        reward = "—" if run["mean_reward"] is None else f'{run["mean_reward"]:.4g}'
        line = f'{run["method"]:<10} {run["stage"]}  seed={run["seed"]}  {run["status"]:<7}  success={rate:<6}  reward={reward:<7}  {run["budget"]}'
        parts.append(f'<text x="64" y="{run_y}" class="body">{esc(line)}</text>')
        run_y += 27
    parts.extend([
        '<line x1="62" y1="458" x2="1538" y2="458" stroke="#334155"/>',
        '<text x="64" y="497" class="h">CODE MODIFICATIONS</text>',
    ])

    changes = result["modified_files"][:8]
    if not changes:
        parts.append('<text x="64" y="535" class="body">No code modifications recorded.</text>')
        code_bottom = 566
    else:
        split = (len(changes) + 1) // 2
        code_bottom = 535
        for column, column_items in enumerate((changes[:split], changes[split:])):
            x_path = 64 + column * 770
            x_change = x_path + 22
            y = 535
            for item in column_items:
                parts.append(f'<text x="{x_path}" y="{y}" class="path">{esc(item["path"])}</text>')
                y = text_lines(parts, x_change, y + 25, wrapped(item["change"], 72), "body", 22)
                y += 9
            code_bottom = max(code_bottom, y)

    lower_y = max(750, min(code_bottom + 10, 790))
    parts.extend([
        f'<line x1="62" y1="{lower_y}" x2="1538" y2="{lower_y}" stroke="#334155"/>',
        f'<text x="64" y="{lower_y + 43}" class="h">ARTIFACTS + HASHES</text>',
        f'<text x="850" y="{lower_y + 43}" class="h">BLOCKERS</text>',
    ])
    artifact_y = lower_y + 81
    for artifact in result["artifacts"][:3]:
        artifact_y = text_lines(parts, 64, artifact_y, ["• " + line for line in wrapped(artifact, 70)], "small", 23)
    blocker_y = lower_y + 81
    blockers = result["blockers"] or ["none"]
    for blocker in blockers[:3]:
        blocker_y = text_lines(parts, 850, blocker_y, ["• " + line for line in wrapped(blocker, 65)], "small", 23)

    parts.extend([
        '<rect x="62" y="920" width="1476" height="38" rx="8" fill="#13263e"/>',
        f'<text x="82" y="946" class="small">NEXT: {esc(result["next_action"])}</text>',
        '</svg>',
    ])
    return "\n".join(parts) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("result", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = json.loads(args.result.read_text(encoding="utf-8"))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(render(result), encoding="utf-8")
    print(f"Wrote {args.output} ({WIDTH}x{HEIGHT})")


if __name__ == "__main__":
    main()
