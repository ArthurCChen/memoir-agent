import unittest

from experiments.trajectory_audit.build_annotation_queue import make_queue
from experiments.trajectory_audit.export_rollouts import export_records
from experiments.trajectory_audit.validate_export import validate_rollouts


class TrajectoryAuditPipelineTest(unittest.TestCase):
    def setUp(self):
        self.source = {
            "non_tensor_batch": {
                "uid": ["task-1", "task-1", "task-1", "task-1"],
                "traj_uid": ["success", "success", "failure", "failure"],
                "anchor_obs": ["at desk", "at sink", "at desk", "at shelf"],
                "next_obs": ["at sink", "clean cup", "at shelf", "still at shelf"],
                "text_actions": ["go sink", "clean cup", "go shelf", "take cup"],
                "episode_rewards": [1.0, 1.0, 0.0, 0.0],
                "step_rewards": [0.0, 1.0, 0.0, 0.0],
            }
        }

    def test_exports_same_prompt_trajectories(self):
        rollouts, groups = export_records(self.source, "test-revision")
        self.assertEqual(len(rollouts), 2)
        self.assertEqual([len(item["steps"]) for item in rollouts], [2, 2])
        self.assertTrue(groups[0]["has_outcome_contrast"])
        self.assertEqual(groups[0]["trajectory_ids"], ["success", "failure"])

    def test_queue_prioritizes_outcome_contrast(self):
        rollouts, _ = export_records(self.source)
        queue = make_queue(rollouts)
        self.assertEqual(len(queue), 4)
        self.assertEqual(queue[0]["criticality"]["label"], None)
        self.assertIn("same_prompt_rollout_contrast", queue[0]["criticality"]["allowed_support_sources"])

    def test_validator_exposes_missing_audit_context(self):
        rollouts, _ = export_records(self.source)
        report = validate_rollouts(rollouts)
        self.assertFalse(report["ready_for_annotation"])
        self.assertEqual(report["outcome_contrast_group_count"], 1)
        self.assertTrue(any("policy-visible context" in item for item in report["warnings"]))


if __name__ == "__main__":
    unittest.main()
