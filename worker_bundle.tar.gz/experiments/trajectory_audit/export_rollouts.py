#!/usr/bin/env python3
"""Export verl-agent/GraphGPO rollout batches into stable JSONL records.

The exporter accepts either a JSON fixture or a PyTorch checkpoint containing a
serialized DataProto-like object. PyTorch and verl are imported only for `.pth`
inputs, allowing schema and queue tests to run on a CPU-only workstation.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable, Mapping


SCHEMA_VERSION = "0.1.0"


def _plain(value: Any) -> Any:
    """Convert tensors, NumPy values, and object arrays to JSON-safe values."""
    if hasattr(value, "detach"):
        value = value.detach().cpu()
    if hasattr(value, "tolist"):
        value = value.tolist()
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    return value


def load_source(path: Path) -> Mapping[str, Any]:
    if path.suffix == ".json":
        return json.loads(path.read_text(encoding="utf-8"))
    if path.suffix not in {".pt", ".pth"}:
        raise ValueError("Input must be .json, .pt, or .pth")

    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("PyTorch is required to read .pt/.pth inputs") from exc

    loaded = torch.load(path, map_location="cpu", weights_only=False)
    if hasattr(loaded, "__dict__") and not isinstance(loaded, Mapping):
        loaded = loaded.__dict__
    if not isinstance(loaded, Mapping):
        raise TypeError(f"Expected a mapping-like checkpoint, got {type(loaded)!r}")
    return loaded


def _columns(source: Mapping[str, Any]) -> dict[str, list[Any]]:
    """Flatten common DataProto storage into row-oriented columns."""
    merged: dict[str, Any] = {}
    for container_name in ("batch", "non_tensor_batch"):
        container = source.get(container_name, {})
        if hasattr(container, "items"):
            merged.update(dict(container.items()))
    for key, value in source.items():
        if key not in {"batch", "non_tensor_batch", "meta_info"}:
            merged.setdefault(key, value)

    result: dict[str, list[Any]] = {}
    for key, value in merged.items():
        plain = _plain(value)
        if isinstance(plain, list):
            result[key] = plain
    return result


def _first(columns: Mapping[str, list[Any]], index: int, *names: str) -> Any:
    for name in names:
        values = columns.get(name)
        if values is not None and index < len(values):
            return values[index]
    return None


def export_records(source: Mapping[str, Any], source_revision: str = "unknown") -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    columns = _columns(source)
    if not columns:
        raise ValueError("No row-like fields found in the input")
    row_count = max(len(values) for values in columns.values())
    trajectories: dict[tuple[str, str], dict[str, Any]] = {}

    for index in range(row_count):
        prompt_group_id = str(_first(columns, index, "uid", "prompt_group_id") or "unknown-group")
        trajectory_id = str(_first(columns, index, "traj_uid", "trajectory_id") or f"row-{index}")
        key = (prompt_group_id, trajectory_id)
        record = trajectories.setdefault(
            key,
            {
                "schema_version": SCHEMA_VERSION,
                "source": {"repository": "langfengQ/verl-agent", "revision": source_revision},
                "prompt_group_id": prompt_group_id,
                "trajectory_id": trajectory_id,
                "task": _first(columns, index, "raw_prompt", "task", "prompt"),
                "terminal_outcome": None,
                "episode_reward": _first(columns, index, "episode_rewards", "episode_reward"),
                "steps": [],
            },
        )
        step = {
            "step_index": len(record["steps"]),
            "context_visible_to_policy": _first(
                columns, index, "model_context_text", "rendered_prompt_text", "raw_prompt"
            ),
            "anchor_observation": _first(columns, index, "anchor_obs", "anchor_observation"),
            "next_observation": _first(columns, index, "next_obs", "next_observation"),
            "decoded_action": _first(columns, index, "text_actions", "decoded_action", "action"),
            "executed_action": _first(columns, index, "executed_action", "projected_action"),
            "reward": _first(columns, index, "step_rewards", "rewards", "reward"),
            "active": _first(columns, index, "active_masks", "active"),
            "memory_snapshot": _first(columns, index, "memory_snapshot", "memory_records"),
            "raw_row_index": index,
        }
        record["steps"].append(step)

    rollout_records = list(trajectories.values())
    for record in rollout_records:
        reward = record.get("episode_reward")
        if isinstance(reward, (int, float)):
            record["terminal_outcome"] = "success" if reward > 0 else "failure"
        else:
            record["terminal_outcome"] = "unknown"
        record["trajectory_length"] = len(record["steps"])

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in rollout_records:
        grouped[record["prompt_group_id"]].append(record)
    group_records = [
        {
            "schema_version": SCHEMA_VERSION,
            "prompt_group_id": group_id,
            "trajectory_ids": [item["trajectory_id"] for item in items],
            "outcomes": [item["terminal_outcome"] for item in items],
            "has_outcome_contrast": len({item["terminal_outcome"] for item in items}) > 1,
        }
        for group_id, items in grouped.items()
    ]
    return rollout_records, group_records


def write_jsonl(path: Path, records: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--source-revision", default="unknown")
    args = parser.parse_args()
    rollouts, groups = export_records(load_source(args.input), args.source_revision)
    write_jsonl(args.output_dir / "rollouts.jsonl", rollouts)
    write_jsonl(args.output_dir / "groups.jsonl", groups)
    print(json.dumps({"rollouts": len(rollouts), "groups": len(groups)}))


if __name__ == "__main__":
    main()
