"""Utilities for exporting and auditing grouped agent trajectories."""
