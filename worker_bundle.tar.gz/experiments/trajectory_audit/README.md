# Trajectory Audit

This package converts grouped `verl-agent` rollout batches into two stable
artifacts:

- `rollouts.jsonl`: one row per trajectory, with ordered policy checkpoints.
- `groups.jsonl`: one row per prompt group, including outcome-contrast status.

It then produces `annotation_queue.jsonl`, one row per trajectory checkpoint.
Rows are intentionally blank with respect to candidate information atoms. A
candidate may only be added when supported by a tool/API precondition, verifier
dependency, producer-to-consumer provenance path, or a same-prompt rollout
contrast. Otherwise, the annotator must abstain.

The current exporter understands GraphGPO/GiGPO fields such as `uid`,
`traj_uid`, `anchor_obs`, `next_obs`, `text_actions`, `episode_rewards`, and
`step_rewards`. For MEMOIR-quality collection, upstream logging should also emit
`model_context_text`, `rendered_prompt_text`, `executed_action`, and
`memory_snapshot` at every step.

## Commands

```bash
python -m experiments.trajectory_audit.export_rollouts \
  /path/to/rollout_batch.pth artifacts/audit-run \
  --source-revision 20bd331bdbc9026a5668e11362178e10ab7400c8

python -m experiments.trajectory_audit.build_annotation_queue \
  artifacts/audit-run/rollouts.jsonl \
  artifacts/audit-run/annotation_queue.jsonl

python -m experiments.trajectory_audit.validate_export \
  artifacts/audit-run/rollouts.jsonl
```

Do not treat an annotation as a causal intervention result. Removal, injection,
and timing rerollouts belong to a later experimental stage.
