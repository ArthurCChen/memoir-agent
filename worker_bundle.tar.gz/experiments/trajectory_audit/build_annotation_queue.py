#!/usr/bin/env python3
"""Build a grounded human-audit queue from exported trajectory groups."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Iterable


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def make_queue(rollouts: Iterable[dict[str, Any]], contrast_only: bool = True) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for rollout in rollouts:
        grouped.setdefault(rollout["prompt_group_id"], []).append(rollout)

    queue: list[dict[str, Any]] = []
    for group_id, items in grouped.items():
        outcomes = {item.get("terminal_outcome") for item in items}
        if len(items) < 2 or (contrast_only and len(outcomes) < 2):
            continue
        comparison_ids = [item["trajectory_id"] for item in items]
        for item in items:
            for step in item.get("steps", []):
                queue.append(
                    {
                        "schema_version": "0.1.0",
                        "annotation_id": f"{group_id}:{item['trajectory_id']}:{step['step_index']}",
                        "prompt_group_id": group_id,
                        "trajectory_id": item["trajectory_id"],
                        "checkpoint_step_index": step["step_index"],
                        "comparison_trajectory_ids": comparison_ids,
                        "semantic_alignment": {"subtask_key": None, "confidence": None, "rationale": None},
                        "checkpoint_evidence": step,
                        "candidates": [],
                        "lifecycle": None,
                        "ownership": None,
                        "criticality": {
                            "label": None,
                            "support_sources": [],
                            "allowed_support_sources": [
                                "tool_or_api_precondition",
                                "verifier_dependency",
                                "producer_consumer_provenance",
                                "same_prompt_rollout_contrast",
                            ],
                        },
                        "replay_feasibility": None,
                        "audit": {"annotator": None, "confidence": None, "adjudication": None},
                    }
                )
    return queue


def write_jsonl(path: Path, records: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("rollouts", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--include-no-contrast", action="store_true")
    args = parser.parse_args()
    queue = make_queue(read_jsonl(args.rollouts), contrast_only=not args.include_no_contrast)
    write_jsonl(args.output, queue)
    print(json.dumps({"annotation_rows": len(queue)}))


if __name__ == "__main__":
    main()
