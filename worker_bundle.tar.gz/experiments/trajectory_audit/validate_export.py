#!/usr/bin/env python3
"""Validate whether exported rollouts are ready for human information audit."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Iterable

from .build_annotation_queue import read_jsonl


def validate_rollouts(rollouts: Iterable[dict[str, Any]]) -> dict[str, Any]:
    items = list(rollouts)
    errors: list[str] = []
    warnings: list[str] = []
    groups: dict[str, list[dict[str, Any]]] = {}

    for rollout in items:
        rollout_id = rollout.get("trajectory_id", "<missing>")
        group_id = rollout.get("prompt_group_id")
        if not group_id:
            errors.append(f"{rollout_id}: missing prompt_group_id")
            continue
        groups.setdefault(group_id, []).append(rollout)
        if not rollout.get("task"):
            warnings.append(f"{rollout_id}: missing human-readable task")
        steps = rollout.get("steps", [])
        if not steps:
            errors.append(f"{rollout_id}: no steps")
        for expected_index, step in enumerate(steps):
            prefix = f"{rollout_id}:step-{expected_index}"
            if step.get("step_index") != expected_index:
                errors.append(f"{prefix}: non-contiguous step_index")
            for field in ("anchor_observation", "decoded_action"):
                if step.get(field) in (None, ""):
                    errors.append(f"{prefix}: missing {field}")
            if step.get("context_visible_to_policy") in (None, ""):
                warnings.append(f"{prefix}: missing exact policy-visible context")
            if step.get("executed_action") in (None, ""):
                warnings.append(f"{prefix}: missing executed action")

    contrast_groups = 0
    for group_id, group_items in groups.items():
        if len(group_items) < 2:
            warnings.append(f"{group_id}: only one trajectory")
        if len({item.get("terminal_outcome") for item in group_items}) > 1:
            contrast_groups += 1

    return {
        "ready_for_annotation": not errors and not warnings,
        "rollout_count": len(items),
        "group_count": len(groups),
        "outcome_contrast_group_count": contrast_groups,
        "errors": errors,
        "warnings": warnings,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("rollouts", type=Path)
    args = parser.parse_args()
    report = validate_rollouts(read_jsonl(args.rollouts))
    print(json.dumps(report, indent=2, ensure_ascii=False))
    raise SystemExit(0 if report["ready_for_annotation"] else 1)


if __name__ == "__main__":
    main()
